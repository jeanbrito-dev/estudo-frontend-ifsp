export default function Card({ logo, title, description }) {
    return (
        <div className="card">
            <div className="logo">{logo}</div>
            <h2>{title}</h2>
            <p>{description}</p>
            <button>Learn More</button>
        </div>
    )
}